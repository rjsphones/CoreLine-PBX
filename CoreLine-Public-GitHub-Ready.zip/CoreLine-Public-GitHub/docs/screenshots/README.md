# Screenshots

Add sanitized screenshots here for:

- CoreLine dashboard
- Extensions
- Phone manager
- Cisco workspace
- UCP
- Windows softphone
- Android softphone

Before committing an image, remove PBX IDs, email addresses, activation codes, SIP credentials, public IP addresses, caller IDs, phone numbers, recordings, and customer data.
