# Troubleshooting

## CoreLine does not start

```bash
node -c /opt/rjpbx/server.js
systemctl status coreline --no-pager -l
journalctl -u coreline -n 150 --no-pager
```

## Extension does not register

```bash
asterisk -rx "pjsip show endpoints"
asterisk -rx "pjsip show contacts"
asterisk -rx "pjsip show endpoint EXTENSION"
```

Check the extension number, authentication username, password, server address, port, transport, firewall, and generated PJSIP include.

## Call connects without audio

Check RTP firewall rules, NAT addresses, `local_net`, `external_media_address`, `external_signaling_address`, `rtp_symmetric`, `force_rport`, `rewrite_contact`, and whether another NAT or SIP ALG is involved.

## Softphone reports 401 or 407

One `401` or `407` followed by an authenticated retry and `200 OK` can be normal digest authentication. Repeated challenges followed by a failure usually indicate a credential, realm, identity, or relay-to-PBX matching problem.

Include the full sanitized sequence of first-line SIP diagnostics in the bug report.
