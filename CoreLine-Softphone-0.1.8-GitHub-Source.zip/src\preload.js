const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("coreline", {
  getState: () => ipcRenderer.invoke("state:get"),
  activate: (data) => ipcRenderer.invoke("activate", data),
  forget: () => ipcRenderer.invoke("account:forget"),
  register: () => ipcRenderer.invoke("sip:register"),
  call: (number) => ipcRenderer.invoke("sip:call", number),
  answer: () => ipcRenderer.invoke("sip:answer"),
  hangup: () => ipcRenderer.invoke("sip:hangup"),
  hold: (held) => ipcRenderer.invoke("sip:hold", held),
  transfer: (number) => ipcRenderer.invoke("sip:transfer", number),
  dtmf: (digit) => ipcRenderer.invoke("sip:dtmf", digit),
  setMuted: (muted) => ipcRenderer.invoke("sip:mute", muted),
  sendAudio: (samples) => ipcRenderer.send("audio:send", samples),
  onState: (callback) => ipcRenderer.on("state", (_, value) => callback(value)),
  onAudio: (callback) => ipcRenderer.on("audio", (_, samples) => callback(samples))
});
