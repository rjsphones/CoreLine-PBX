# CoreLine Softphones

CoreLine has beta softphones for Windows and Android.

## Activation modes

- **Local/direct:** server IP address and a single-use registration activation code
- **Remote/PBX ID:** public PBX ID and activation code through CoreLine Connect testing

## Before reporting a failure

Include the platform, app version, activation mode, sanitized diagnostics, call direction, remote extension, network type, and exact error code.

Never post an activation code, SIP password, device secret, PBX enrollment secret, or private customer information.

## Android installation

Android may require permission to install an APK from the browser or file manager used to download it. Only install an APK whose checksum matches the official release.

## System ringtone

Future Android builds are expected to use the device's configured system ringtone where supported.
