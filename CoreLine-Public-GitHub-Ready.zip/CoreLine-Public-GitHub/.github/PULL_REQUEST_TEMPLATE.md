## Summary

Describe the documentation, template, or compatibility change.

## Reason

Explain what was incorrect, missing, or confusing.

## Verification

- [ ] Links were checked.
- [ ] Commands were reviewed for safety and syntax.
- [ ] No CoreLine private source was added.
- [ ] No credentials, keys, activation codes, customer data, recordings, or private logs were added.
- [ ] No copyrighted firmware or unlicensed media was added.
- [ ] Planned features are not presented as complete.

## Screenshots

Add sanitized screenshots only when they materially help review the documentation.
