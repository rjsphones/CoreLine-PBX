const $ = (id) => document.getElementById(id);
let current = {};
let muted = false;
let held = false;
let callConnected = false;
let audioContext;
let microphone;
let processor;
let playCursor = 0;
let toneContext;
let ringbackTimer;
let incomingTimer;
let incomingRinging = false;
let ringbackPlaying = false;

for (const key of ["1","2","3","4","5","6","7","8","9","*","0","#"]) {
  const button = document.createElement("button");
  button.className = "key";
  button.textContent = key;
  button.addEventListener("click", async () => {
    if (callConnected) {
      try { await window.coreline.dtmf(key); } catch (error) { showError(error); }
    } else {
      $("number").value += key;
    }
  });
  $("keypad").appendChild(button);
}

function showError(error) {
  $("error").textContent = error?.message || String(error || "");
}

async function ensureAudio() {
  if (audioContext) return;
  audioContext = new AudioContext({ sampleRate: 48000 });
  const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
  microphone = audioContext.createMediaStreamSource(stream);
  processor = audioContext.createScriptProcessor(4096, 1, 1);
  processor.onaudioprocess = (event) => {
    const source = event.inputBuffer.getChannelData(0);
    const ratio = audioContext.sampleRate / 8000;
    const out = new Int16Array(Math.floor(source.length / ratio));
    for (let i = 0; i < out.length; i++) out[i] = Math.max(-32768, Math.min(32767, source[Math.floor(i * ratio)] * 32767));
    window.coreline.sendAudio(Array.from(out));
  };
  microphone.connect(processor);
  processor.connect(audioContext.destination);
}

function play(samples) {
  if (!audioContext) return;
  const ratio = audioContext.sampleRate / 8000;
  const buffer = audioContext.createBuffer(1, samples.length * ratio, audioContext.sampleRate);
  const channel = buffer.getChannelData(0);
  for (let i = 0; i < channel.length; i++) channel[i] = samples[Math.floor(i / ratio)] / 32768;
  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(audioContext.destination);
  playCursor = Math.max(playCursor, audioContext.currentTime + .02);
  source.start(playCursor);
  playCursor += buffer.duration;
}

function scheduleTone(frequencies, start, duration, volume = 0.1, type = "sine") {
  if (!toneContext) return;
  const gain = toneContext.createGain();
  gain.gain.setValueAtTime(0.0001, start);
  gain.gain.exponentialRampToValueAtTime(volume, start + 0.02);
  gain.gain.setValueAtTime(volume, start + Math.max(0.03, duration - 0.05));
  gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
  gain.connect(toneContext.destination);
  for (const frequency of frequencies) {
    const oscillator = toneContext.createOscillator();
    oscillator.type = type;
    oscillator.frequency.value = frequency;
    oscillator.connect(gain);
    oscillator.start(start);
    oscillator.stop(start + duration + 0.03);
  }
}

function ringbackCadence() {
  if (!ringbackPlaying || !toneContext) return;
  const now = toneContext.currentTime + 0.03;
  scheduleTone([440, 480], now, 1.9, 0.075, "sine");
}

function incomingCadence() {
  if (!incomingRinging || !toneContext) return;
  const now = toneContext.currentTime + 0.03;

  scheduleTone([523.25, 659.25], now, 0.16, 0.09, "triangle");
  scheduleTone([659.25, 783.99], now + 0.22, 0.16, 0.09, "triangle");
  scheduleTone([587.33, 880], now + 0.48, 0.34, 0.08, "sine");
}

async function ensureToneContext() {
  toneContext ||= new AudioContext();
  await toneContext.resume().catch(() => {});
}

async function startIncomingRingtone() {
  if (incomingRinging) return;
  stopRingback();
  incomingRinging = true;
  await ensureToneContext();
  incomingCadence();
  incomingTimer = setInterval(incomingCadence, 3500);
}

function stopIncomingRingtone() {
  incomingRinging = false;
  clearInterval(incomingTimer);
  incomingTimer = null;
}

async function startRingback() {
  if (ringbackPlaying) return;
  stopIncomingRingtone();
  ringbackPlaying = true;
  await ensureToneContext();
  ringbackCadence();
  ringbackTimer = setInterval(ringbackCadence, 6000);
}

function stopRingback() {
  ringbackPlaying = false;
  clearInterval(ringbackTimer);
  ringbackTimer = null;
}

function render(state) {
  current = state;
  $("activation").hidden = state.activated;
  $("phone").hidden = !state.activated;
  $("extension").textContent = state.extension || "—";
  $("registration").textContent = state.registration || "—";
  $("statusDot").classList.toggle("on", state.registration === "Registered");
  const callState = state.call?.state || "Idle";
  $("callState").textContent = state.call?.number ? `${callState} • ${state.call.number}` : callState;
  const incoming = callState === "Incoming";
  const failed = callState.startsWith("Failed");
  const active = !["Idle", ""].includes(callState) && !failed;
  const connected = ["In call", "On hold", "Holding", "Resuming", "Transferring", "Transfer failed"].some((value) => callState.startsWith(value));
  callConnected = connected;
  held = callState === "On hold" || callState === "Holding";
  $("callBtn").hidden = active;
  $("callToolbar").hidden = !active;
  $("answerBtn").hidden = !incoming;
  $("muteBtn").hidden = !connected;
  $("holdBtn").hidden = !connected;
  $("holdBtn").textContent = held ? "Resume" : "Hold";
  $("transferBtn").hidden = !connected;
  $("number").disabled = active;
  if (state.call?.number && active) $("number").value = state.call.number;
  if (incoming) startIncomingRingtone().catch(showError); else stopIncomingRingtone();
  if (callState === "Ringing") startRingback().catch(showError); else stopRingback();
}

$("activateBtn").addEventListener("click", async () => {
  showError("");
  $("activateBtn").disabled = true;
  try { render(await window.coreline.activate({ server: $("server").value, code: $("code").value })); }
  catch (error) { showError(error); }
  finally { $("activateBtn").disabled = false; }
});
async function placeCall() {
  showError("");
  try { await ensureAudio(); await window.coreline.call($("number").value); } catch (error) { showError(error); }
}

$("callBtn").addEventListener("click", placeCall);
$("number").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !$("callBtn").hidden && !$("callBtn").disabled) {
    event.preventDefault();
    placeCall();
  }
});
document.addEventListener("keydown", async (event) => {
  if (!callConnected || event.ctrlKey || event.altKey || event.metaKey) return;
  if (/^[0-9*#]$/.test(event.key)) {
    event.preventDefault();
    try { await window.coreline.dtmf(event.key); } catch (error) { showError(error); }
  }
});
$("answerBtn").addEventListener("click", async () => {
  try { await ensureAudio(); await window.coreline.answer(); } catch (error) { showError(error); }
});
$("hangupBtn").addEventListener("click", () => window.coreline.hangup());
$("holdBtn").addEventListener("click", async () => {
  try { await window.coreline.hold(!held); } catch (error) { showError(error); }
});
$("transferBtn").addEventListener("click", async () => {
  const destination = window.prompt("Transfer this call to which extension or number?");
  if (!destination) return;
  try { await window.coreline.transfer(destination); } catch (error) { showError(error); }
});
$("reconnectBtn").addEventListener("click", async () => {
  try { await window.coreline.register(); } catch (error) { showError(error); }
});
$("muteBtn").addEventListener("click", async () => {
  muted = !muted;
  $("muteBtn").textContent = muted ? "Unmute" : "Mute";
  await window.coreline.setMuted(muted);
});
$("forgetBtn").addEventListener("click", async () => render(await window.coreline.forget()));
window.coreline.onState(render);
window.coreline.onAudio(play);
window.coreline.getState().then(render);
