# Release Checksums

Publish checksums in the matching GitHub Release notes. This directory may also contain text checksum manifests, but never place private signing keys or keystores here.

Suggested manifest format:

```text
SHA256  filename.apk
SHA256  filename.exe
```
