# CoreLine VERSION — Beta

Release date: YYYY-MM-DD

## Status

This is a beta release. Do not depend on it as the only telephone or emergency communication system.

## Changes

- Change one
- Change two

## Fixed

- Fix one

## Known issues

- Known issue one

## Assets

| File | Platform | SHA-256 |
| --- | --- | --- |
| `CoreLine-Softphone-VERSION.exe` | Windows | `REPLACE` |
| `CoreLine-Softphone-Android-VERSION.apk` | Android | `REPLACE` |

## Upgrade

Explain whether the existing version can be upgraded in place and whether settings remain compatible.

## Rollback

Explain how to reinstall the previous known-good build.

## Testing performed

- Installation or upgrade
- Registration
- Inbound and outbound calls
- Answer and hang-up
- Audio in both directions
- DTMF
- Local and remote network behavior
