# Upgrading CoreLine

Back up the current system before every beta upgrade.

```bash
sudo cp /opt/rjpbx/server.js /opt/rjpbx/server-backup-$(date +%F-%H%M%S).js
curl -fsSL https://corelines.xyz/install/upgrade.sh | sudo bash
systemctl status coreline --no-pager -l
```

Verify:

- Administrator login
- UCP login
- Existing extensions and phones
- Trunk registration
- Inbound and outbound calls
- Audio in both directions
- DTMF
- Voicemail
- Paging and parking
- Softphone activation

Never replace a working `server.js` until `node -c` succeeds against the staged `.js` file. Keep the previous working file until testing is complete.
