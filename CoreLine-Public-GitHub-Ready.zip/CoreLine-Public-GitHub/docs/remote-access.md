# Remote Access and CoreLine Connect

CoreLine Connect is beta remote-access infrastructure intended to let approved softphones use a PBX ID instead of a private server address.

It currently involves SIP authentication, Kamailio signaling, RTPengine media relay, a PBX enrollment agent, and Asterisk routing. Registration success alone does not prove that calls and audio work in both directions.

Test all of the following:

- Registration from a different network
- Outbound call setup
- Inbound call setup
- Answer and remote hang-up
- Audio in both directions
- DTMF
- NAT changes
- Cellular and Wi-Fi networks

Do not expose Asterisk AMI or the CoreLine admin panel publicly as a shortcut for remote access.
