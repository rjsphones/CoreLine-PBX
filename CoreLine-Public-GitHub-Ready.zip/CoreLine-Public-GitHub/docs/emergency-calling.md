# Emergency Calling

CoreLine is PBX software. It does not automatically provide telephone numbers, PSTN access, emergency routing, dispatchable location, provider registration, power backup, internet backup, or regulatory compliance.

Before production use:

- Confirm emergency service with the trunk provider.
- Register the correct service location.
- Understand requirements for remote and nomadic users.
- Configure emergency routes that cannot be blocked by ordinary dialing restrictions.
- Use the provider's approved non-emergency test process.
- Maintain another verified way to contact emergency services.
- Inform users of limitations during outages or relocation.

Never place an unnecessary live emergency call simply to test a PBX.
