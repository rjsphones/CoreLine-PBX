const { app, BrowserWindow, ipcMain, safeStorage } = require("electron");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { SipClient } = require("./sip-client");

let window;
let sip;
let state = { activated: false, registration: "Not configured", call: { state: "Idle", number: "" } };

function configPath() {
  return path.join(app.getPath("userData"), "account.json");
}

function loadConfig() {
  try {
    const saved = JSON.parse(fs.readFileSync(configPath(), "utf8"));
    const json = safeStorage.decryptString(Buffer.from(saved.encrypted, "base64"));
    return JSON.parse(json);
  } catch {
    return null;
  }
}

function saveConfig(config) {
  if (!safeStorage.isEncryptionAvailable()) throw new Error("Windows credential encryption is unavailable.");
  fs.mkdirSync(path.dirname(configPath()), { recursive: true });
  const encrypted = safeStorage.encryptString(JSON.stringify(config)).toString("base64");
  fs.writeFileSync(configPath(), JSON.stringify({ version: 1, encrypted }), { mode: 0o600 });
}

function update(patch) {
  state = { ...state, ...patch };
  window?.webContents.send("state", state);
}

function attachSip(config) {
  sip?.close();
  sip = new SipClient(config);
  sip.on("status", (registration) => update({ registration }));
  sip.on("call", (call) => update({ call }));
  sip.on("audio", (samples) => window?.webContents.send("audio", Array.from(samples)));
  sip.on("error", (error) => update({ registration: `Error: ${error}` }));
}

async function register() {
  const config = loadConfig();
  if (!config) throw new Error("Activate this softphone first.");
  if (!sip) attachSip(config);
  await sip.register();
}

app.whenReady().then(async () => {
  window = new BrowserWindow({
    width: 410,
    height: 690,
    minWidth: 380,
    minHeight: 620,
    backgroundColor: "#050b18",
    title: "CoreLine Softphone Beta",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  window.setMenuBarVisibility(false);
  await window.loadFile(path.join(__dirname, "index.html"));
  const config = loadConfig();
  if (config) {
    state = { ...state, activated: true, extension: config.extension, server: config.server, registration: "Starting" };
    attachSip(config);
    register().catch((error) => update({ registration: `Error: ${error.message}` }));
  }
});

app.on("window-all-closed", () => {
  sip?.close();
  if (process.platform !== "darwin") app.quit();
});

ipcMain.handle("state:get", () => state);
ipcMain.handle("activate", async (_, details) => {
  const server = String(details.server || "").trim().replace(/\/+$/, "");
  const code = String(details.code || "").trim().toUpperCase();
  if (!server || !code) throw new Error("Enter the CoreLine server and activation code.");
  let parsed;
  try {
    parsed = new URL(/^https?:\/\//i.test(server) ? server : `http://${server}`);
  } catch {
    throw new Error("Enter a valid CoreLine address, such as 192.168.1.50 or http://192.168.1.50:8080.");
  }

  const explicitPort = parsed.port !== "";
  const bases = explicitPort
    ? [`${parsed.protocol}//${parsed.host}`]
    : parsed.protocol === "https:"
      ? [`https://${parsed.hostname}`, `http://${parsed.hostname}:8080`, `http://${parsed.hostname}`]
      : [`http://${parsed.hostname}:8080`, `http://${parsed.hostname}`];
  const deviceId = crypto.createHash("sha256").update(`${app.getPath("userData")}:${require("os").hostname()}`).digest("hex");
  let result = null;
  const failures = [];

  for (const base of [...new Set(bases)]) {
    try {
      const response = await fetch(`${base}/api/softphone/activate`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ code, deviceId }),
        signal: AbortSignal.timeout(8000)
      });
      const contentType = response.headers.get("content-type") || "";
      const body = contentType.includes("application/json")
        ? await response.json()
        : { error: `CoreLine returned ${contentType || "a non-JSON response"} on ${base}` };
      if (response.ok && body.ok) {
        result = body;
        break;
      }
      if (response.status === 400 && body.error) {
        throw new Error(body.error);
      }
      failures.push(`${base}: ${body.error || `HTTP ${response.status}`}`);
    } catch (error) {
      if (/Invalid or expired activation code|Extension not found/i.test(error.message || "")) throw error;
      failures.push(`${base}: ${error.cause?.code || error.name || "connection failed"} ${error.message || ""}`.trim());
    }
  }

  if (!result) {
    throw new Error(
      `Could not reach the CoreLine activation API. Tried ${[...new Set(bases)].join(" and ")}. ` +
      `Check that the CoreLine service is running and TCP port 8080 or 80 is allowed. ${failures.join(" | ")}`
    );
  }
  const config = {
    server: result.server || parsed.hostname,
    port: Number(result.port || 5060),
    extension: String(result.extension),
    username: String(result.username || result.extension),
    password: String(result.password),
    transport: "udp",
    deviceId
  };
  saveConfig(config);
  attachSip(config);
  update({ activated: true, extension: config.extension, server: config.server, registration: "Starting" });
  register().catch((error) => update({ registration: `SIP error: ${error.message}` }));
  return state;
});
ipcMain.handle("account:forget", () => {
  sip?.close(); sip = null;
  try { fs.unlinkSync(configPath()); } catch {}
  update({ activated: false, extension: "", server: "", registration: "Not configured", call: { state: "Idle", number: "" } });
});
ipcMain.handle("sip:register", () => register());
ipcMain.handle("sip:call", async (_, number) => {
  if (!sip) await register();
  await sip.call(String(number || "").trim());
});
ipcMain.handle("sip:answer", () => sip?.answer());
ipcMain.handle("sip:hangup", () => sip?.hangup());
ipcMain.handle("sip:hold", (_, held) => sip?.hold(held));
ipcMain.handle("sip:transfer", (_, number) => sip?.transfer(number));
ipcMain.handle("sip:dtmf", (_, digit) => sip?.sendDtmf(digit));
ipcMain.handle("sip:mute", (_, muted) => { if (sip) sip.muted = Boolean(muted); });
ipcMain.on("audio:send", (_, samples) => sip?.sendPcm(samples));
