# Supported Phone Work

Support varies by phone model, firmware, SIP/SCCP mode, and provisioning behavior.

## Cisco groundwork

- 7811, 7821, 7841, and 7861 Enterprise
- 8811, 8841, 8845, 8851, 8861, and 8865 Enterprise
- 7941, 7962, 7965, and 7975 SIP
- Generic Cisco SCCP
- Generic Cisco 3PCC/MPP
- Cisco XML directory and services
- Cisco XML push groundwork
- Ringtone lists and background lists
- KEM groundwork on supported models

## Other brands

- Yealink SIP groundwork
- Grandstream SIP groundwork
- Polycom SIP groundwork
- Panasonic SIP groundwork
- Generic SIP provisioning

## Compatibility report requirements

Include the exact model, firmware version, protocol, provisioning method, registration result, working features, failing features, and sanitized phone/PBX logs.

Do not upload copyrighted firmware to GitHub.
