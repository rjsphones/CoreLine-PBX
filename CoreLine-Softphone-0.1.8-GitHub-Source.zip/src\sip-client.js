const dgram = require("dgram");
const crypto = require("crypto");
const { EventEmitter } = require("events");

const CRLF = "\r\n";
const md5 = (value) => crypto.createHash("md5").update(value).digest("hex");
const token = (bytes = 8) => crypto.randomBytes(bytes).toString("hex");

function parseMessage(buffer) {
  const text = buffer.toString("utf8");
  const split = text.indexOf("\r\n\r\n");
  const head = split >= 0 ? text.slice(0, split) : text;
  const body = split >= 0 ? buffer.subarray(split + 4) : Buffer.alloc(0);
  const lines = head.split(/\r\n/);
  const headers = {};
  for (const line of lines.slice(1)) {
    const colon = line.indexOf(":");
    if (colon > 0) headers[line.slice(0, colon).trim().toLowerCase()] = line.slice(colon + 1).trim();
  }
  return { start: lines[0], headers, body, raw: text };
}

function digestHeader(challenge, method, uri, username, password) {
  const params = {};
  challenge.replace(/(\w+)=(?:"([^"]*)"|([^,\s]+))/g, (_, key, quoted, plain) => {
    params[key.toLowerCase()] = quoted ?? plain;
    return "";
  });
  const realm = params.realm || "";
  const nonce = params.nonce || "";
  const qop = (params.qop || "").split(",")[0].trim();
  const cnonce = token();
  const nc = "00000001";
  const ha1 = md5(`${username}:${realm}:${password}`);
  const ha2 = md5(`${method}:${uri}`);
  const response = qop
    ? md5(`${ha1}:${nonce}:${nc}:${cnonce}:${qop}:${ha2}`)
    : md5(`${ha1}:${nonce}:${ha2}`);
  let value = `Digest username="${username}", realm="${realm}", nonce="${nonce}", uri="${uri}", response="${response}"`;
  if (params.algorithm) value += `, algorithm=${params.algorithm}`;
  if (params.opaque) value += `, opaque="${params.opaque}"`;
  if (qop) value += `, qop=${qop}, nc=${nc}, cnonce="${cnonce}"`;
  return value;
}

function pcmToUlaw(sample) {
  const BIAS = 0x84;
  let sign = sample < 0 ? 0x80 : 0;
  if (sample < 0) sample = -sample;
  sample = Math.min(32635, sample) + BIAS;
  let exponent = 7;
  for (let mask = 0x4000; exponent > 0 && !(sample & mask); mask >>= 1) exponent--;
  const mantissa = (sample >> (exponent + 3)) & 0x0f;
  return (~(sign | (exponent << 4) | mantissa)) & 0xff;
}

function ulawToPcm(value) {
  value = (~value) & 0xff;
  const sign = value & 0x80;
  const exponent = (value >> 4) & 7;
  const mantissa = value & 15;
  let sample = ((mantissa << 3) + 0x84) << exponent;
  sample -= 0x84;
  return sign ? -sample : sample;
}

class SipClient extends EventEmitter {
  constructor(config) {
    super();
    this.config = config;
    this.socket = null;
    this.rtp = null;
    this.localPort = 0;
    this.rtpPort = 0;
    this.cseq = 1;
    this.registerCallId = `${token()}@coreline`;
    this.registrationTimer = null;
    this.dialog = null;
    this.pendingInvite = null;
    this.muted = false;
    this.rtpSequence = Math.floor(Math.random() * 65535);
    this.rtpTimestamp = Math.floor(Math.random() * 0xffffffff);
    this.ssrc = crypto.randomBytes(4).readUInt32BE(0);
    this.advertisedAddress = "";
  }

  async start() {
    if (this.socket) return;
    this.socket = dgram.createSocket("udp4");
    this.socket.on("message", (message, remote) => this.onSip(message, remote));
    this.socket.on("error", (error) => this.emit("error", error.message));
    await new Promise((resolve) => this.socket.bind(0, "0.0.0.0", resolve));
    this.localPort = this.socket.address().port;
    this.rtp = dgram.createSocket("udp4");
    this.rtp.on("message", (packet) => this.onRtp(packet));
    await new Promise((resolve) => this.rtp.bind(0, "0.0.0.0", resolve));
    this.rtpPort = this.rtp.address().port;
    this.advertisedAddress = await this.discoverLocalAddress();
  }

  async discoverLocalAddress() {
    const probe = dgram.createSocket("udp4");
    try {
      await new Promise((resolve, reject) => {
        probe.once("error", reject);
        probe.connect(Number(this.config.port || 5060), this.host(), resolve);
      });
      return probe.address().address;
    } catch {
      return this.fallbackLocalAddress();
    } finally {
      try { probe.close(); } catch {}
    }
  }

  host() {
    return String(this.config.server).replace(/^https?:\/\//, "").replace(/[:/].*$/, "");
  }

  uri(number = this.config.username) {
    return `sip:${number}@${this.host()}`;
  }

  contact() {
    return `<sip:${this.config.username}@${this.localAddress()}:${this.localPort};transport=udp>`;
  }

  localAddress() {
    return this.advertisedAddress || this.fallbackLocalAddress();
  }

  fallbackLocalAddress() {
    const interfaces = require("os").networkInterfaces();
    for (const group of Object.values(interfaces)) {
      const item = group?.find((x) => x.family === "IPv4" && !x.internal);
      if (item) return item.address;
    }
    return "127.0.0.1";
  }

  send(lines, body = "", port = Number(this.config.port || 5060), host = this.host()) {
    const payload = Buffer.from([...lines, `Content-Length: ${Buffer.byteLength(body)}`, "", body].join(CRLF));
    this.socket.send(payload, port, host);
  }

  common(method, target, callId, tag, branch, cseq, extra = []) {
    return [
      `${method} ${target} SIP/2.0`,
      `Via: SIP/2.0/UDP ${this.localAddress()}:${this.localPort};branch=${branch};rport`,
      "Max-Forwards: 70",
      `From: "CoreLine ${this.config.extension}" <${this.uri()}>;tag=${tag}`,
      `To: <${target}>`,
      `Call-ID: ${callId}`,
      `CSeq: ${cseq} ${method}`,
      `Contact: ${this.contact()}`,
      "User-Agent: CoreLine-Softphone-Beta/0.1.0",
      ...extra
    ];
  }

  async register(auth) {
    await this.start();
    const target = this.uri();
    const tag = this.registerTag || (this.registerTag = token());
    const branch = `z9hG4bK${token()}`;
    const cseq = this.cseq++;
    const extras = ["Expires: 300"];
    if (auth) extras.push(`Authorization: ${auth}`);
    this.send(this.common("REGISTER", target, this.registerCallId, tag, branch, cseq, extras));
    this.lastRegister = { target, tag, cseq };
    this.emit("status", "Registering");
  }

  createSdp(direction = "sendrecv") {
    const ip = this.localAddress();
    return [
      "v=0",
      `o=coreline 1 1 IN IP4 ${ip}`,
      "s=CoreLine Softphone",
      `c=IN IP4 ${ip}`,
      "t=0 0",
      `m=audio ${this.rtpPort} RTP/AVP 0 101`,
      "a=rtpmap:0 PCMU/8000",
      "a=rtpmap:101 telephone-event/8000",
      "a=fmtp:101 0-16",
      `a=${direction}`,
      ""
    ].join(CRLF);
  }

  async call(number, auth, authHeader = "Authorization") {
    await this.start();
    if (!auth) {
      const target = this.uri(number);
      this.dialog = {
        direction: "outgoing", target, number,
        callId: `${token()}@coreline`,
        localTag: token(), branch: `z9hG4bK${token()}`, cseq: this.cseq++
      };
    }
    const d = this.dialog;
    const extras = [
      "Allow: INVITE, ACK, CANCEL, BYE, OPTIONS",
      "Supported: replaces",
      "Content-Type: application/sdp"
    ];
    if (auth) extras.push(`${authHeader}: ${auth}`);
    d.branch = `z9hG4bK${token()}`;
    this.send(this.common("INVITE", d.target, d.callId, d.localTag, d.branch, d.cseq, extras), this.createSdp());
    this.emit("call", { state: "Calling", number: d.number });
  }

  answer() {
    const p = this.pendingInvite;
    if (!p) return;
    const to = p.message.headers.to.includes(";tag=") ? p.message.headers.to : `${p.message.headers.to};tag=${p.localTag}`;
    this.send([
      "SIP/2.0 200 OK",
      `Via: ${p.message.headers.via}`,
      `From: ${p.message.headers.from}`,
      `To: ${to}`,
      `Call-ID: ${p.message.headers["call-id"]}`,
      `CSeq: ${p.message.headers.cseq}`,
      `Contact: ${this.contact()}`,
      "Content-Type: application/sdp"
    ], this.createSdp(), p.remote.port, p.remote.address);
    this.dialog = { direction: "incoming", ...p, to };
    this.dialog.established = true;
    this.dialog.localUri = this.uri();
    this.dialog.remoteUri = p.message.headers.from?.match(/<([^>]+)>/)?.[1] || this.uri(p.number);
    this.dialog.remoteTarget = p.message.headers.contact?.match(/<([^>]+)>/)?.[1] || this.dialog.remoteUri;
    this.dialog.remoteTag = p.message.headers.from?.match(/;tag=([^;>\s]+)/)?.[1] || "";
    this.pendingInvite = null;
    this.emit("call", { state: "In call", number: this.dialog.number });
  }

  hangup() {
    if (this.pendingInvite && !this.dialog) {
      const p = this.pendingInvite;
      this.send([
        "SIP/2.0 486 Busy Here",
        `Via: ${p.message.headers.via}`,
        `From: ${p.message.headers.from}`,
        `To: ${p.message.headers.to};tag=${p.localTag}`,
        `Call-ID: ${p.message.headers["call-id"]}`,
        `CSeq: ${p.message.headers.cseq}`
      ], "", p.remote.port, p.remote.address);
      this.pendingInvite = null;
      this.emit("call", { state: "Idle", number: "" });
      return;
    }
    const d = this.dialog;
    if (!d) return;
    const target = d.remoteTarget || d.target;
    if (d.direction === "outgoing" && !d.established) {
      this.send([
        `CANCEL ${d.target} SIP/2.0`,
        `Via: SIP/2.0/UDP ${this.localAddress()}:${this.localPort};branch=${d.branch};rport`,
        `From: <${this.uri()}>;tag=${d.localTag}`,
        `To: <${d.target}>`,
        `Call-ID: ${d.callId}`,
        `CSeq: ${d.cseq} CANCEL`
      ]);
    } else {
      const remoteTag = d.remoteTag ? `;tag=${d.remoteTag}` : "";
      this.send([
        `BYE ${target} SIP/2.0`,
        `Via: SIP/2.0/UDP ${this.localAddress()}:${this.localPort};branch=z9hG4bK${token()};rport`,
        "Max-Forwards: 70",
        `From: <${d.localUri || this.uri()}>;tag=${d.localTag}`,
        `To: <${d.remoteUri || target}>${remoteTag}`,
        `Call-ID: ${d.callId}`,
        `CSeq: ${this.cseq++} BYE`,
        `Contact: ${this.contact()}`,
        "User-Agent: CoreLine-Softphone-Beta/0.1.3"
      ], "", d.remote?.port || Number(this.config.port || 5060), d.remote?.address || this.host());
    }
    this.dialog = null;
    this.emit("call", { state: "Idle", number: "" });
  }

  hold(held) {
    const d = this.dialog;
    if (!d?.established) throw new Error("A connected call is required.");
    const target = d.remoteTarget || d.target;
    d.cseq = this.cseq++;
    d.branch = `z9hG4bK${token()}`;
    d.holdPending = Boolean(held);
    this.send([
      `INVITE ${target} SIP/2.0`,
      `Via: SIP/2.0/UDP ${this.localAddress()}:${this.localPort};branch=${d.branch};rport`,
      "Max-Forwards: 70",
      `From: <${d.localUri || this.uri()}>;tag=${d.localTag}`,
      `To: <${d.remoteUri || target}>;tag=${d.remoteTag || ""}`,
      `Call-ID: ${d.callId}`,
      `CSeq: ${d.cseq} INVITE`,
      `Contact: ${this.contact()}`,
      "Content-Type: application/sdp",
      "User-Agent: CoreLine-Softphone-Beta/0.1.3"
    ], this.createSdp(held ? "sendonly" : "sendrecv"), d.remote?.port || Number(this.config.port || 5060), d.remote?.address || this.host());
    this.emit("call", { state: held ? "Holding" : "Resuming", number: d.number });
  }

  transfer(number) {
    const d = this.dialog;
    const destination = String(number || "").trim();
    if (!d?.established) throw new Error("A connected call is required.");
    if (!/^[0-9*#+]+$/.test(destination)) throw new Error("Enter a valid transfer destination.");
    const target = d.remoteTarget || d.target;
    const cseq = this.cseq++;
    d.transferCseq = cseq;
    this.send([
      `REFER ${target} SIP/2.0`,
      `Via: SIP/2.0/UDP ${this.localAddress()}:${this.localPort};branch=z9hG4bK${token()};rport`,
      "Max-Forwards: 70",
      `From: <${d.localUri || this.uri()}>;tag=${d.localTag}`,
      `To: <${d.remoteUri || target}>;tag=${d.remoteTag || ""}`,
      `Call-ID: ${d.callId}`,
      `CSeq: ${cseq} REFER`,
      `Contact: ${this.contact()}`,
      `Refer-To: <${this.uri(destination)}>`,
      `Referred-By: <${this.uri()}>`,
      "Event: refer",
      "User-Agent: CoreLine-Softphone-Beta/0.1.3"
    ], "", d.remote?.port || Number(this.config.port || 5060), d.remote?.address || this.host());
    this.emit("call", { state: "Transferring", number: d.number });
  }

  sendDtmf(digit) {
    const d = this.dialog;
    const value = String(digit || "").toUpperCase();
    const eventMap = { "0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9, "*": 10, "#": 11, "A": 12, "B": 13, "C": 14, "D": 15 };
    if (!d?.established) throw new Error("A connected call is required.");
    if (!(value in eventMap)) throw new Error("DTMF must be 0-9, *, or #.");
    if (!this.remoteRtp) throw new Error("The call has no active RTP destination.");

    const event = eventMap[value];
    const eventTimestamp = this.rtpTimestamp >>> 0;
    const packets = [
      { duration: 160, end: false, marker: true },
      { duration: 320, end: false, marker: false },
      { duration: 480, end: false, marker: false },
      { duration: 640, end: true, marker: false },
      { duration: 640, end: true, marker: false },
      { duration: 640, end: true, marker: false }
    ];

    packets.forEach((details, index) => {
      setTimeout(() => {
        if (!this.dialog || !this.remoteRtp) return;
        const packet = Buffer.alloc(16);
        packet[0] = 0x80;
        packet[1] = (details.marker ? 0x80 : 0) | 101;
        packet.writeUInt16BE(this.rtpSequence++ & 0xffff, 2);
        packet.writeUInt32BE(eventTimestamp, 4);
        packet.writeUInt32BE(this.ssrc >>> 0, 8);
        packet[12] = event;
        packet[13] = (details.end ? 0x80 : 0) | 10;
        packet.writeUInt16BE(details.duration, 14);
        this.rtp.send(packet, this.remoteRtp.port, this.remoteRtp.host);
      }, index * 20);
    });
    this.rtpTimestamp = (this.rtpTimestamp + 800) >>> 0;
  }

  onSip(buffer, remote) {
    const m = parseMessage(buffer);
    if (m.start.startsWith("SIP/2.0")) return this.onResponse(m, remote);
    const [method] = m.start.split(" ");
    if (method === "INVITE") {
      if (this.dialog?.established) {
        this.send(["SIP/2.0 486 Busy Here", `Via: ${m.headers.via}`, `From: ${m.headers.from}`, `To: ${m.headers.to}`, `Call-ID: ${m.headers["call-id"]}`, `CSeq: ${m.headers.cseq}`], "", remote.port, remote.address);
        return;
      }
      const match = m.headers.from?.match(/sip:([^@;>]+)/i);
      const number = match?.[1] || "Unknown";
      const sdp = m.body.toString();
      this.setRemoteRtp(sdp, remote.address);
      this.pendingInvite = { message: m, remote, localTag: token(), number, callId: m.headers["call-id"] };
      this.send(["SIP/2.0 100 Trying", `Via: ${m.headers.via}`, `From: ${m.headers.from}`, `To: ${m.headers.to}`, `Call-ID: ${m.headers["call-id"]}`, `CSeq: ${m.headers.cseq}`], "", remote.port, remote.address);
      this.send([
        "SIP/2.0 180 Ringing", `Via: ${m.headers.via}`, `From: ${m.headers.from}`,
        `To: ${m.headers.to};tag=${this.pendingInvite.localTag}`, `Call-ID: ${m.headers["call-id"]}`,
        `CSeq: ${m.headers.cseq}`
      ], "", remote.port, remote.address);
      this.emit("call", { state: "Incoming", number });
    } else if (method === "BYE") {
      this.send(["SIP/2.0 200 OK", `Via: ${m.headers.via}`, `From: ${m.headers.from}`, `To: ${m.headers.to}`, `Call-ID: ${m.headers["call-id"]}`, `CSeq: ${m.headers.cseq}`], "", remote.port, remote.address);
      this.dialog = null;
      this.emit("call", { state: "Idle", number: "" });
    } else if (method === "OPTIONS") {
      this.send(["SIP/2.0 200 OK", `Via: ${m.headers.via}`, `From: ${m.headers.from}`, `To: ${m.headers.to}`, `Call-ID: ${m.headers["call-id"]}`, `CSeq: ${m.headers.cseq}`, `Contact: ${this.contact()}`, "Allow: INVITE, ACK, CANCEL, BYE, OPTIONS, REFER"], "", remote.port, remote.address);
    } else if (method === "NOTIFY") {
      this.send(["SIP/2.0 200 OK", `Via: ${m.headers.via}`, `From: ${m.headers.from}`, `To: ${m.headers.to}`, `Call-ID: ${m.headers["call-id"]}`, `CSeq: ${m.headers.cseq}`], "", remote.port, remote.address);
    }
  }

  onResponse(m, remote) {
    const status = Number(m.start.split(" ")[1]);
    const cseqMethod = m.headers.cseq?.split(" ")[1];
    if (cseqMethod === "REFER" && status >= 200 && status < 300 && this.dialog) {
      this.emit("call", { state: "Transferred", number: this.dialog.number });
      setTimeout(() => this.hangup(), 400);
      return;
    }
    if (cseqMethod === "REFER" && status >= 300 && this.dialog) {
      this.emit("call", { state: `Transfer failed (${status})`, number: this.dialog.number });
      return;
    }
    if ((status === 401 || status === 407) && cseqMethod === "REGISTER") {
      const challenge = m.headers["www-authenticate"] || m.headers["proxy-authenticate"];
      return this.register(digestHeader(challenge, "REGISTER", this.lastRegister.target, this.config.username, this.config.password));
    }
    if (status === 200 && cseqMethod === "REGISTER") {
      this.emit("status", "Registered");
      clearTimeout(this.registrationTimer);
      this.registrationTimer = setTimeout(() => this.register(), 240000);
      return;
    }
    if ((status === 401 || status === 407) && cseqMethod === "INVITE") {
      if (!this.dialog) return;
      const isProxy = status === 407;
      const challenge = isProxy ? m.headers["proxy-authenticate"] : m.headers["www-authenticate"];
      if (!challenge) {
        this.emit("call", { state: "Failed: missing authentication challenge", number: this.dialog.number });
        this.dialog = null;
        return;
      }
      return this.call(
        this.dialog.number,
        digestHeader(challenge, "INVITE", this.dialog.target, this.config.username, this.config.password),
        isProxy ? "Proxy-Authorization" : "Authorization"
      );
    }
    if (cseqMethod === "INVITE" && status >= 180 && status < 200) {
      this.emit("call", { state: "Ringing", number: this.dialog?.number || "" });
    }
    if (cseqMethod === "INVITE" && status === 200 && this.dialog) {
      const sdp = m.body.toString();
      this.setRemoteRtp(sdp, remote.address);
      const toTag = m.headers.to?.match(/;tag=([^;>\s]+)/)?.[1];
      this.dialog.remoteTag = toTag;
      this.dialog.remote = remote;
      this.dialog.established = true;
      this.dialog.remoteTarget = m.headers.contact?.match(/<([^>]+)>/)?.[1] || this.dialog.target;
      this.dialog.localUri = this.uri();
      this.dialog.remoteUri = m.headers.to?.match(/<([^>]+)>/)?.[1] || this.dialog.target;
      this.send([
        `ACK ${this.dialog.remoteTarget} SIP/2.0`,
        `Via: SIP/2.0/UDP ${this.localAddress()}:${this.localPort};branch=z9hG4bK${token()};rport`,
        "Max-Forwards: 70",
        `From: <${this.uri()}>;tag=${this.dialog.localTag}`,
        `To: ${m.headers.to}`,
        `Call-ID: ${this.dialog.callId}`,
        `CSeq: ${this.dialog.cseq} ACK`,
        `Contact: ${this.contact()}`
      ], "", remote.port, remote.address);
      if (this.dialog.holdPending !== undefined) {
        this.dialog.held = this.dialog.holdPending;
        delete this.dialog.holdPending;
      }
      this.emit("call", { state: this.dialog.held ? "On hold" : "In call", number: this.dialog.number });
      return;
    }
    if (cseqMethod === "INVITE" && status >= 300 && this.dialog) {
      const number = this.dialog.number;
      this.dialog = null;
      this.emit("call", { state: `Failed (${status})`, number });
    }
  }

  setRemoteRtp(sdp, fallbackHost) {
    const host = sdp.match(/^c=IN IP4 ([^\r\n]+)/m)?.[1] || fallbackHost;
    const port = Number(sdp.match(/^m=audio (\d+)/m)?.[1]);
    if (host && port) this.remoteRtp = { host, port };
  }

  sendPcm(samples) {
    if (!this.remoteRtp || this.muted || !this.dialog || this.dialog.held) return;
    const input = new Int16Array(samples);
    for (let offset = 0; offset + 160 <= input.length; offset += 160) {
      const packet = Buffer.alloc(12 + 160);
      packet[0] = 0x80; packet[1] = 0;
      packet.writeUInt16BE(this.rtpSequence++ & 0xffff, 2);
      packet.writeUInt32BE(this.rtpTimestamp >>> 0, 4);
      packet.writeUInt32BE(this.ssrc >>> 0, 8);
      for (let i = 0; i < 160; i++) packet[12 + i] = pcmToUlaw(input[offset + i]);
      this.rtpTimestamp = (this.rtpTimestamp + 160) >>> 0;
      this.rtp.send(packet, this.remoteRtp.port, this.remoteRtp.host);
    }
  }

  onRtp(packet) {
    if (!this.dialog || packet.length <= 12 || (packet[1] & 0x7f) !== 0) return;
    const cc = packet[0] & 0x0f;
    const offset = 12 + cc * 4;
    const samples = new Int16Array(packet.length - offset);
    for (let i = offset; i < packet.length; i++) samples[i - offset] = ulawToPcm(packet[i]);
    this.emit("audio", samples);
  }

  close() {
    clearTimeout(this.registrationTimer);
    this.socket?.close();
    this.rtp?.close();
  }
}

module.exports = { SipClient, parseMessage, digestHeader, pcmToUlaw, ulawToPcm };
