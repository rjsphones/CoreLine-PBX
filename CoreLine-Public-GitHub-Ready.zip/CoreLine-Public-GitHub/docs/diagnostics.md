# Diagnostics and Privacy

Useful diagnostics include timestamps, SIP request/response first lines, response codes, call states, service status, and relevant error messages.

Remove or replace:

- SIP passwords
- Authorization headers
- Activation codes
- PBX enrollment secrets
- API tokens
- Private keys
- Personal phone numbers
- Email addresses
- Public IP addresses when disclosure is unnecessary
- Customer names and recordings

Do not publish full packet captures without reviewing every packet. SIP captures commonly contain phone numbers, internal addresses, authentication material, call metadata, and SDP media details.
