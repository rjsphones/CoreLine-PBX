# Releases and Checksums

Official compiled softphones and installation packages belong in GitHub Releases, not in ordinary Git history.

Each release should include:

- Version and release date
- Beta or stable status
- Supported operating systems
- Changes and known problems
- Upgrade instructions
- Rollback instructions
- Exact asset filenames
- SHA-256 checksums
- Signing information where applicable

Example verification:

```bash
sha256sum downloaded-file.apk
```

On PowerShell:

```powershell
Get-FileHash .\downloaded-file.exe -Algorithm SHA256
```

The output must exactly match the checksum published in the same GitHub Release.
