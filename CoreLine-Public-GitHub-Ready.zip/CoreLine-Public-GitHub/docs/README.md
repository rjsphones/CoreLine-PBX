# CoreLine Documentation

- [Installation](installation.md)
- [Upgrading](upgrading.md)
- [Softphones](softphones.md)
- [Supported phones](supported-phones.md)
- [Remote access](remote-access.md)
- [Troubleshooting](troubleshooting.md)
- [Diagnostics and privacy](diagnostics.md)
- [Emergency calling](emergency-calling.md)
- [Release downloads and checksums](releases.md)
- [Release-notes template](release-notes-template.md)

Documentation applies to the latest public beta unless a page says otherwise.
