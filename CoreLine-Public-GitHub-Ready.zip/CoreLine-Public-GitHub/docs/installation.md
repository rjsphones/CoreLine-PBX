# Installing CoreLine PBX

> Beta warning: test CoreLine before depending on it for real users or telephone service.

## Target system

- Debian 12 Bookworm
- A dedicated machine, VM, or VPS
- Root or sudo access
- Stable network configuration
- Adequate disk space for voicemail and recordings
- A backup or snapshot before installation

## Installation command

```bash
curl -fsSL https://corelines.xyz/install/install.sh | sudo bash
```

Running a remote script as root is powerful. Review the script from the official CoreLine website before executing it.

## After installation

```bash
systemctl status coreline --no-pager -l
systemctl status asterisk --no-pager -l
asterisk -rx "core show version"
asterisk -rx "pjsip show endpoints"
```

Open the local CoreLine administration address and immediately change the default administrator password. Create a test extension before adding trunks or public routes.

## Do not expose immediately

Do not place the administration interface, AMI, provisioning files, or SIP service directly on the public internet without a security plan. Use firewall restrictions, strong credentials, updates, monitoring, and preferably a VPN for administration.
